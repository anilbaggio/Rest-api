package com.test;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping(value="/response")
public class Controller {

	@Autowired
	Impl im;
	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public List Details(@RequestBody Cbean b,Model model)
	{
		
		//System.out.println("safdf");
		List total=new ArrayList();
		total=im.getValue(b);
		return total;
		
	}
	
}
