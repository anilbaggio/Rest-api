package com.test;





import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Sanction_Info")
public class Sanction_Info {
	private String Sanction_ID;
	private String Sanctions_List_Type;
	private String Score;
	private String Matched_Content;
	private String Matched_Column;

	public Sanction_Info(){}
	public void Sancion_Info(String Sanction_ID,String Sanctions_List_Type,String Score,String Matched_Content,String Matched_Column)
	{
		this.Sanction_ID=Sanction_ID;
		this.Sanctions_List_Type=Sanctions_List_Type;
		this.Score=Score;
		this.Matched_Content=Matched_Content;
		this.Matched_Column=Matched_Column;
	}
	public String getSanction_ID() {
		return Sanction_ID;
	}
	@XmlElement(name="Sanction_ID")
	public void setSanction_ID(String sanction_ID) {
		Sanction_ID = sanction_ID;
	}
	public String getSanctions_List_Type() {
		return Sanctions_List_Type;
	}
	@XmlElement(name="Sanctions_List_Type")
	public void setSanctions_List_Type(String sanctions_List_Type) {
		Sanctions_List_Type = sanctions_List_Type;
	}
	public String getScore() {
		return Score;
	}
	@XmlElement(name="Score")
	public void setScore(String score) {
		Score = score;
	}
	public String getMatched_Content() {
		return Matched_Content;
	}
	@XmlElement(name="Matched_Content")
	public void setMatched_Content(String matched_Content) {
		Matched_Content = matched_Content;
	}
	public String getMatched_Column() {
		return Matched_Column;
	}
	@XmlElement(name="Matched_Column")
	public void setMatched_Column(String matched_Column) {
		Matched_Column = matched_Column;
	}

}
