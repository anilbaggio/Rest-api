package com.test;



import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class Impl implements Ixml {

	public List getValue(Cbean b) {

	//	System.out.println(b.getDate_time_of_response());
		//System.out.println(b.getAPPSOURCE());
     List Values=new ArrayList();
     String Response_Type=b.getResponse_Type();
     String Entity_type=b.getEntity_type();
     String Date_time_of_response=b.getDate_time_of_response();
     String APPSOURCE=b.getAPPSOURCE();
     String Error_Code=b.getError_Code();
     String Final_Score=b.getFinal_Score();
     String Watchlist_Match=b.getWatchlist_Match();
     Values.add(Response_Type);
     Values.add(Entity_type);
     Values.add(Date_time_of_response);
     Values.add(APPSOURCE);
     Values.add(Error_Code);
     Values.add(Final_Score);
     Values.add(Watchlist_Match);
     
     for(int i=0;i<b.getSanction_Info().size();i++)
     {
    	 String Sanction_ID=b.getSanction_Info().get(i).getSanction_ID();
    	 String Sanctions_List_Type=b.getSanction_Info().get(i).getSanctions_List_Type();
    	 String Score=b.getSanction_Info().get(i).getScore();
    	 String Matched_Content=b.getSanction_Info().get(i).getMatched_Content();
    	 String Matched_Column=b.getSanction_Info().get(i).getMatched_Column();
    	 Values.add(Sanction_ID);
    	 Values.add(Sanctions_List_Type);
    	 Values.add(Score);
    	 Values.add(Matched_Content);
    	 Values.add(Matched_Column);
     }
		return Values;
	}

}
 