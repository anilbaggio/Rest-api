package com.test;




import java.util.List;

public interface Ixml {
	public List getValue(Cbean b);

}
