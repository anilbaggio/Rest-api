package com.test;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Response")
public class Cbean {
	private String Response_Type;
	private String Entity_type;
	private String Date_time_of_response;
	private String APPSOURCE;
	private String Error_Code;
	private String Final_Score;
	private String Watchlist_Match;
	public String getResponse_Type() {
		return Response_Type;
	}
	@XmlElement(name="Response_Type")
	public void setResponse_Type(String response_Type) {
		Response_Type = response_Type;
	}
	public String getEntity_type() {
		return Entity_type;
	}
	@XmlElement(name="Entity_type")
	public void setEntity_type(String entity_type) {
		Entity_type = entity_type;
		//System.out.println("dffsf : "+entity_type);
	}
	public String getDate_time_of_response() {
		return Date_time_of_response;
	}
	@XmlElement(name="Date_time_of_response")
	public void setDate_time_of_response(String date_time_of_response) {
		Date_time_of_response = date_time_of_response;
	}
	public String getAPPSOURCE() {
		return APPSOURCE;
	}
	@XmlElement(name="APPSOURCE")
	public void setAPPSOURCE(String aPPSOURCE) {
		APPSOURCE = aPPSOURCE;
		//System.out.println(aPPSOURCE);
	}
	public String getError_Code() {
		return Error_Code;
	}
	@XmlElement(name="Error_Code")
	public void setError_Code(String error_Code) {
		Error_Code = error_Code;
	}
	public String getFinal_Score() {
		return Final_Score;
	}
	@XmlElement(name="Final_Score")
	public void setFinal_Score(String final_Score) {
		Final_Score = final_Score;
	}
	public String getWatchlist_Match() {
		return Watchlist_Match;
	}
	@XmlElement(name="Watchlist_Match")
	public void setWatchlist_Match(String watchlist_Match) {
		Watchlist_Match = watchlist_Match;
	}
	
	private List<Sanction_Info> Sanction_Info;
	
	public List<Sanction_Info> getSanction_Info() {
		return Sanction_Info;
	}
	@XmlElement(name="Sanction_Info")
	public void setSanction_Info(List<Sanction_Info> Sanction_Info) {
		this.Sanction_Info = Sanction_Info;
	}
	

}
