package com.tra.dao;

import java.util.List;

import com.tra.bean.CookieBean;
public interface ISessionValidationDAO
{
	public int getTotal(CookieBean bean);
}
