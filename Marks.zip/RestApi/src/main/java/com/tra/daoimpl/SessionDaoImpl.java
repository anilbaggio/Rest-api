package com.tra.daoimpl;

import java.sql.Types;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DaoSupport;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.tra.bean.CookieBean;
import com.tra.dao.ISessionValidationDAO;
@Component
public class SessionDaoImpl implements ISessionValidationDAO
{

	public int getTotal(CookieBean bean) {
		// TODO Auto-generated method stub
		int total = 0;
		int mark1=bean.getMark1();
		int mark2=bean.getMark2();
		int mark3=bean.getMark3();
		total=mark1+mark2+mark3;
		
				
		return total;
	}

	

}
