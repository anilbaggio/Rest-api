package com.tra.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.tra.daoimpl.SessionDaoImpl;
import com.tra.bean.CookieBean;
@RestController
@RequestMapping(value="/marks")
public class SessionController 
{
	@Autowired
	SessionDaoImpl daoImpl;
	@RequestMapping(value="/getTotal",method=RequestMethod.POST)
	public int setCookieDetails(@RequestBody CookieBean bean,Model model)
	{
		int total=0;
		total=daoImpl.getTotal(bean);
		return total;
		
	}
	}
